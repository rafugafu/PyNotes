python "C:/Program Files/PyNotes/main.py" %*

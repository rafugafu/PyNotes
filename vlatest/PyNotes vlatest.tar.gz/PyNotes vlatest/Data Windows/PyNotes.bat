python "C:/Program Files/PyNotes/PyNotes.py" %*

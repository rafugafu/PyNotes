echo Set oWS = WScript.CreateObject("WScript.Shell") > CreateShortcutWithIcon.vbs
echo Set oLink = oWS.CreateShortcut("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\PyNotes.lnk") >> CreateShortcutWithIcon.vbs
echo oLink.TargetPath = "C:\Program Files\PyNotes\pynotes.bat" >> CreateShortcutWithIcon.vbs
echo oLink.IconLocation = "C:\Program Files\PyNotes\Icon.ico" >> CreateShortcutWithIcon.vbs
echo oLink.Save >> CreateShortcutWithIcon.vbs
cscript //nologo CreateShortcutWithIcon.vbs
del CreateShortcutWithIcon.vbs

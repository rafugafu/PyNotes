import pyray as pr
import math
import random

def main():
    pr.init_window(800, 600, "aMaze Game")
    pr.rl_set_line_width(3)
    camera = pr.Camera3D((0,0.5,0), (1,0.5,1), (0,1,0), 60, pr.CAMERA_PERSPECTIVE)
    map_size = 10
    player = Player()

    while not pr.window_should_close():
        player.controls()
        camera.position = player.pos
        camera.target = pr.vector3_add(player.pos, player.direction)
        camera.up = (0,1,0)
        pr.begin_drawing()
        pr.clear_background(pr.SKYBLUE)
        pr.begin_mode_3d(camera)
        
        pr.draw_grid(map_size*10, 0.2)
        pr.draw_plane((0, -0.01, 0), (map_size*2 , map_size*2 ), pr.WHITE)
        pr.end_mode_3d()
        pr.end_drawing()

class Player():
    def __init__(self):
        self.pos = pr.Vector3(1.5,0.5,1.5)
        self.yaw = 0
        self.pitch = 0
        self.sensitivity = 0.003
        self.direction = pr.Vector3(1,0,1)
        self.speed = 2
        pr.disable_cursor()
    
    def controls(self):
        speed = pr.get_frame_time()*self.speed
        mouse_delta = pr.get_mouse_delta()
        self.yaw -= mouse_delta.x * self.sensitivity
        self.pitch  = max(-1.57, min(1.57, self.pitch - mouse_delta.y*self.sensitivity))
        sin_yaw, cos_yaw = math.sin(self.yaw), math.cos(self.yaw)
        
        # adjust camera pointing direction
        self.direction.x = math.cos(self.pitch ) * sin_yaw
        self.direction.y = math.sin(self.pitch )
        self.direction.z = math.cos(self.pitch ) * cos_yaw

        forward = pr.is_key_down(pr.KEY_W) - pr.is_key_down(pr.KEY_S)
        sideward = pr.is_key_down(pr.KEY_D) - pr.is_key_down(pr.KEY_A)
        if forward != 0 and sideward != 0:
            speed *= 0.707 # adjust speed when moving diagonally

        nx, nz = self.pos.x, self.pos.z

        nx += speed * (sin_yaw*forward - cos_yaw*sideward)
        nz += speed * (cos_yaw*forward + sin_yaw*sideward)

        self.pos.x, self.pos.z = nx, nz

main()
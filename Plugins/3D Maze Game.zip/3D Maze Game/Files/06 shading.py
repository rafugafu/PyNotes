import pyray as pr
import math
import random

def main():
    pr.init_window(800, 600, "aMaze Game")
    pr.rl_set_line_width(3)
    camera = pr.Camera3D((0,0.5,0), (1,0.5,1), (0,1,0), 60, pr.CAMERA_PERSPECTIVE)

    player = Player()
    maze = Maze()

    while not pr.window_should_close():
        player.controls(maze)
        camera.position = player.pos
        camera.target = pr.vector3_add(player.pos, player.direction)
        camera.up = (0,1,0)
        pr.begin_drawing()
        pr.clear_background(pr.SKYBLUE)
        pr.begin_mode_3d(camera)
        pr.draw_sphere((player.pos.x-150, 500, player.pos.z), 25, (255, 245, 100, 255))
        pr.draw_grid(maze.size*10, 0.2)
        pr.draw_plane((0, -0.01, 0), (maze.size*2 , maze.size*2 ), pr.WHITE)

        for i in range(maze.size ):
            for j in range(maze.size):
                if maze.maze[i][j] != 0:
                    height = maze.heights[i][j]
                    pr.draw_cube((i+0.5, 0.5*height, j+0.5), 1, height, 1, maze.colors[i][j])
                    pr.draw_cube_wires((i+0.5, 0.5*height, j+0.5), 1, height, 1, pr.BLACK)
                    pr.draw_cube((i+0.502, 0.5*height-0.002, j+0.502), 1, height, 1, (0,0,0,105))
                    pr.draw_cube((i+0.503, 0.5*height-0.003, j+0.498), 1, height, 1, (0,0,0,55))
                    pr.draw_plane((i+1, 0.01, j+0.5), (0.7*height,1), (0,0,0,100))
        
        pr.draw_capsule((maze.exit[0]+0.5, 0.35, maze.exit[1]+0.5), 
                        (maze.exit[0]+0.5, 0.7, maze.exit[1]+0.5), 0.35, 10, 10, (200,200,0,155))
        pr.end_mode_3d()
        pr.end_drawing()

class Player():
    def __init__(self):
        self.pos = pr.Vector3(1.5,0.5,1.5)
        self.yaw = 0
        self.pitch = 0
        self.sensitivity = 0.003
        self.direction = pr.Vector3(1,0,1)
        self.speed = 2
        pr.disable_cursor()
    
    def controls(self, maze):
        speed = pr.get_frame_time()*self.speed
        mouse_delta = pr.get_mouse_delta()
        self.yaw -= mouse_delta.x * self.sensitivity
        self.pitch  = max(-1.57, min(1.57, self.pitch - mouse_delta.y*self.sensitivity))
        sin_yaw, cos_yaw = math.sin(self.yaw), math.cos(self.yaw)
        
        # adjust camera pointing direction
        self.direction.x = math.cos(self.pitch ) * sin_yaw
        self.direction.y = math.sin(self.pitch )
        self.direction.z = math.cos(self.pitch ) * cos_yaw

        forward = pr.is_key_down(pr.KEY_W) - pr.is_key_down(pr.KEY_S)
        sideward = pr.is_key_down(pr.KEY_D) - pr.is_key_down(pr.KEY_A)
        if forward != 0 and sideward != 0:
            speed *= 0.707 # adjust speed when moving diagonally

        nx, nz = self.pos.x, self.pos.z

        nx += speed * (sin_yaw*forward - cos_yaw*sideward)
        nz += speed * (cos_yaw*forward + sin_yaw*sideward)

        if maze.no_collision(nx, nz):
            self.pos.x, self.pos.z = nx, nz
        elif maze.no_collision(nx, self.pos.z):
            self.pos.x = nx
        elif maze.no_collision(self.pos.x, nz):
            self.pos.z = nz

class Maze():
    def __init__(self, size=15):
        self.size = size
        self.maze = None
        self.exit = None
        self.colors = None
        self.heights = None

        self.generate_random_maze()
        
    def generate_random_maze(self):
        maze = [[1] * self.size for _ in range(self.size)]
        self.colors = [[[random.randint(0, 255) for _ in range(3)] +
                    [255] for _ in range(self.size)] for _ in range(self.size)]
        self.heights = [[round(random.uniform(0.2, 2), 1) for _ in range(self.size)] for _ in range(self.size)]

        def carve(x, y):
            maze[x][y] = 0
            dirs = [(2, 0), (-2, 0), (0, 2), (0, -2)]
            random.shuffle(dirs)
            for dx, dy in dirs:
                nx, ny = x + dx, y + dy
                if 1 <= nx < self.size - 1 and 1 <= ny < self.size - 1 and maze[nx][ny] == 1:
                    maze[x + dx // 2][y + dy // 2] = 0
                    carve(nx, ny)

        carve(1, 1)
        for _ in range(self.size * 2): # remove random blocks to create loops
            maze[random.randint(1, self.size-2)][random.randint(1, self.size-2)] = 0

        self.exit = random.randint(2, self.size - 2), random.randint(2, self.size - 2)
        maze[self.exit[0]][self.exit[1]] = 0
        self.maze = maze
    
    def no_collision(self, nx, nz):
        if (self.maze[int(nx)][int(nz)] != 0 or self.maze[int(nx+0.1)][int(nz)] != 0 or 
            self.maze[int(nx)][int(nz+0.1)] != 0 or self.maze[int(nx-0.1)][int(nz)] != 0 or
            self.maze[int(nx)][int(nz-0.1)] != 0 or self.maze[int(nx-0.1)][int(nz-0.1)] != 0):
            return 0
        return 1

main()
import pyray as pr
import math
import random

def main():
    pr.init_window(800, 600, "aMaze Game")

    while not pr.window_should_close():
        pr.begin_drawing()
        pr.clear_background(pr.SKYBLUE)
        pr.end_drawing()

main()
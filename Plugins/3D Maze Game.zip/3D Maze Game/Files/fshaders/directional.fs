#version 300 es
precision highp float;

in vec3 fragNormal;
in vec2 fragTexCoord;
in vec4 fragColor;
in vec4 fragPosition;

uniform sampler2D texture0;
uniform vec4 colDiffuse;
uniform vec3 lightDir;
uniform vec3 lightColor;

out vec4 finalColor;

void main()
{
    vec3 normal = normalize(fragNormal);
    float diff = max(dot(fragNormal, -normalize(lightDir)), 0.25);

    vec4 lighting = vec4(diff * lightColor, 1.0);

    vec4 texel = texture(texture0, fragTexCoord);
    
    finalColor = lighting * texel * colDiffuse * fragColor;
}
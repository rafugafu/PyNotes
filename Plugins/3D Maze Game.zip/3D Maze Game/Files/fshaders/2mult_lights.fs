#version 300 es
#define MAX_LIGHTS 4

precision highp float;

in vec3 fragNormal;
in vec2 fragTexCoord;
in vec4 fragColor;
in vec3 fragPos;

uniform vec3 viewPos;
uniform float specularStrength; // e.g. 0.5
uniform float shininess;        // e.g. 32.0
uniform sampler2D texture0;
uniform vec4 colDiffuse;
uniform int lightCount;
uniform vec3 lightDir;
uniform vec3 lightColorDir;
uniform vec3 lightPos[MAX_LIGHTS];
uniform vec3 lightColor[MAX_LIGHTS];
uniform float lightRadius[MAX_LIGHTS];

out vec4 finalColor;

void main()
{
    float ambient = 0.25;
    vec3 normal = normalize(fragNormal);
    float diff = max(dot(fragNormal, -normalize(lightDir)), 0.0);

    vec3 lighting = (ambient + diff) * lightColorDir; // base ambient

    for (int i = 0; i < lightCount; i++)
    {
        vec3 toLight = lightPos[i] - fragPos;
        float distance = length(toLight);

        if (distance > lightRadius[i])
            continue;

        vec3 lightDir = normalize(toLight);
        float attenuation = clamp(1.0 - distance / lightRadius[i], 0.0, 1.0);

        float diff = max(dot(normal, lightDir), 0.0);

        // Specular
        vec3 viewDir = normalize(viewPos - fragPos);
        vec3 halfDir = normalize(lightDir + viewDir);
        float spec = pow(max(dot(normal, halfDir), 0.0), shininess);
        vec3 specular = specularStrength * spec * lightColor[i];

        lighting +=
            (diff * attenuation * lightColor[i]) +
            (specular * attenuation);
    }

    vec4 texel = texture(texture0, fragTexCoord);
    vec3 color = lighting * texel.rgb * colDiffuse.rgb * fragColor.rgb;

    finalColor = vec4(color, texel.a * colDiffuse.a * fragColor.a);

}

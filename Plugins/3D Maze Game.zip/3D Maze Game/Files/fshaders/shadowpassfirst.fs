#version 300 es
precision highp float;

in vec3 fragNormal;
in vec2 fragTexCoord;
in vec4 fragColor;
in vec4 fragPosition;

out vec4 finalColor;

void main()
{   
    float dummy = 0.00000001*fragColor.r+ 0.00000001*fragNormal.x+ 0.00000001*fragTexCoord.x + 0.00000001*fragPosition.x;
    float depth = gl_FragCoord.z;

    finalColor = vec4(depth, depth, depth, 1.0+dummy*0.0000000000001);

}
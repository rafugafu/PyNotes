#version 300 es
#define MAX_LIGHTS 4
precision highp float;

in vec3 fragNormal;
in vec2 fragTexCoord;
in vec4 fragPosition;
in vec4 fragColor;

uniform sampler2D texture0;
uniform vec4 colDiffuse;
uniform vec3 lightDir;
uniform vec3 lightColor;
uniform sampler2D shadowMap;
uniform mat4 lightVP;
uniform int shadowMapSize;

uniform vec3 viewPos;
const float specularStrength = 0.5;
const float shininess = 32.0;
uniform int lightCount;
uniform vec3 lightPos[MAX_LIGHTS];
uniform vec3 lightColorList[MAX_LIGHTS];
uniform float lightRadius[MAX_LIGHTS];

out vec4 finalColor;

const int SAMPLE_COUNT = 16;

const vec2 poissonSamples[16] = vec2[](
    vec2(-0.94201624, -0.39906216),
    vec2( 0.94558609, -0.76890725),
    vec2(-0.09418410, -0.92938870),
    vec2( 0.34495938,  0.29387760),
    vec2(-0.91588581,  0.45771432),
    vec2(-0.81544232, -0.87912464),
    vec2(-0.38277543,  0.27676845),
    vec2( 0.97484398,  0.75648379),
    vec2( 0.44323325, -0.97511554),
    vec2( 0.53742981, -0.47373420),
    vec2(-0.26496911, -0.41893023),
    vec2( 0.79197514,  0.19090188),
    vec2(-0.24188840,  0.99706507),
    vec2(-0.81409955,  0.91437590),
    vec2( 0.19984126,  0.78641367),
    vec2( 0.14383161, -0.14100790)
);

const vec3 bitShift = vec3(1.0/(256.0*256.0), 1.0/256.0, 1.0);

float shadowFactor()
{   
    vec3 normal = normalize(fragNormal);
    vec3 l = -normalize(lightDir);

    vec4 fragPosLightSpace = lightVP*fragPosition;
    fragPosLightSpace.xyz /= fragPosLightSpace.w; // Perform the perspective division
    fragPosLightSpace.xyz = (fragPosLightSpace.xyz * 0.5 + 0.5); // Transform from [-1, 1] range to [0, 1] range

    if (fragPosLightSpace.x < 0.0 || fragPosLightSpace.x > 1.0 || //fragPosLightSpace.z > 1.0 ||
    fragPosLightSpace.y < 0.0 || fragPosLightSpace.y > 1.0)
    {
        return 1.0;
    }
      
    float bias = max(0.0008*(1.0 - dot(normal, -l)), 0.00008);

    float shadowCounter = 0.0;
    
    vec2 texelSize = vec2(1.0/float(shadowMapSize));
    for (int i = 0; i < SAMPLE_COUNT; i++){
        vec3 sampleColor = texture(shadowMap, fragPosLightSpace.xy + texelSize*poissonSamples[i]).rgb;
        if (fragPosLightSpace.z*30.0 - bias > dot(sampleColor, bitShift)) shadowCounter++;
        //if (fragPosLightSpace.z*60.0 -0.4 - bias > dot(sampleColor, bitShift)) shadowCounter++;
    }

    return mix(1.0, 0.4, shadowCounter / float(SAMPLE_COUNT));

}

void main()
{

    vec3 normal = normalize(fragNormal);
    float diff = max(dot(normal, -normalize(lightDir)), 0.0);

    float ambient = 0.25;
    vec3 lighting = (ambient + diff) * lightColor;

    vec3 pointLights = vec3(0.0);
    for (int i = 0; i < lightCount; i++)
    {
        vec3 toLight = lightPos[i] - fragPosition.xyz;
        float distance = length(toLight);

        if (distance > lightRadius[i])
            continue;

        vec3 lightPointDir = normalize(toLight);
        float attenuation = clamp(1.0 - distance / lightRadius[i], 0.0, 1.0);

        float diff = max(dot(normal, lightPointDir), 0.0);

        // Specular
        vec3 viewDir = normalize(viewPos - fragPosition.xyz);
        vec3 halfDir = normalize(lightPointDir + viewDir);
        float spec = pow(max(dot(normal, halfDir), 0.0), shininess);
        vec3 specular = specularStrength * spec * lightColorList[i];

        pointLights +=
            (diff * attenuation * lightColorList[i]) +
            (specular * attenuation);
    }

    vec4 texel = texture(texture0, fragTexCoord);
    vec3 color = lighting * texel.rgb * colDiffuse.rgb * fragColor.rgb;

    float shadow = shadowFactor();
    color = clamp(pointLights+color*shadow, 0.0, 1.0);
    finalColor = vec4(color, texel.a * colDiffuse.a * fragColor.a);
}


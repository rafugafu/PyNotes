import pyray as pr
import math
import random

def main():
    pr.init_window(800, 600, "aMaze Game")
    pr.rl_set_line_width(3)
    camera = pr.Camera3D((0,0.5,0), (1,0.5,1), (0,1,0), 60, pr.CAMERA_PERSPECTIVE)
    map_size = 10

    while not pr.window_should_close():
        pr.begin_drawing()
        pr.clear_background(pr.SKYBLUE)
        pr.begin_mode_3d(camera)        
        pr.draw_grid(map_size*10, 0.2)
        pr.draw_plane((0, -0.01, 0), (map_size*2 , map_size*2 ), pr.WHITE)
        pr.end_mode_3d()
        pr.end_drawing()

main()